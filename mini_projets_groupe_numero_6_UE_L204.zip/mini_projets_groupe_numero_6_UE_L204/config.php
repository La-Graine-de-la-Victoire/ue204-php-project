<?php
/**
 * =======================
 * = DATABASE CONFIGURATION =
 * =======================
 */
const DB_HOST = 'localhost';

// If is empty, it will use the default port
const DB_PORT = '';
const DB_USER = 'root';
const DB_PASS = '';
const DB_NAME = 'ludotheque';

/**
 * ======================
 * = WEBSITE CONFIGURATION =
 * ======================
 * Used for e-mails
 */
const WEBSITE_DOMAIN = 'localhost';
const WEBSITE_PORT = ':8888';
const WEBSITE_URL = 'http://'. WEBSITE_DOMAIN. WEBSITE_PORT;
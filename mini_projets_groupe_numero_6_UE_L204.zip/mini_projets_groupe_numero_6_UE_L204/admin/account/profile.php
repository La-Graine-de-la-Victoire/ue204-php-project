<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/style.css">
    <title>Connexion/Inscription</title>
</head>
<body>

<div>
    <a href="/account/account.php">MON COMPTE</a>
</div>       

<div>
    <a href="/account/orders.php">MES COMMANDES</a>
</div>     

<div>
    <a href="/account/account.php">PARAMETRES</a>
</div>  

</body>
</html>
<?php

header('Location: /admin/product/list.php');
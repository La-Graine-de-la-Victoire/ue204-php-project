# ue204-php-project
PHP project in Unit 204.

Bonjour je suis une modification.

## Database connection

| Field    | Value                 |
|----------|-----------------------|
| Host     | localhost / 127.0.0.1 |
| DB Name  | ludotheque            |
| User     | root                  |
| Password |                       |

The password field is empty.

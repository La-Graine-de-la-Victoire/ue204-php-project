<?php

header('Location: /admin/user/list.php');
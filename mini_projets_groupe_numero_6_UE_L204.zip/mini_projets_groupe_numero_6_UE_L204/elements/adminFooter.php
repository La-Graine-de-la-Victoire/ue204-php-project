<footer class="admin-footer">
    <div class="admin-footer-links-boxes">
        <ul class="admin-footer-links">
            <li>Informations légales</li>
            <li><a href="/legal/legal.php">Mentions légales</a></li>
        </ul>
        <ul class="admin-footer-links">
            <li>Mon espace réservé</li>
            <li><a href="/account/account.php">Mon compte</a></li>
            <li><a href="/admin">Espace administration</a></li>
        </ul>
    </div>
    <div class="copyright-box">
        <p>Copyright ©, tous les droits sont réservés à la Graine de la Victoire. </p>
    </div>
</footer>
<!-- End of HTML tag opened in adminTop.php -->
</html>
<?php

//
// Access not authorized
header('Location: /');